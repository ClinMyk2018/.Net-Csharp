﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W4.T2.ClinardMykal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        struct StructString
        {
            public String txt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StructString S1 = new StructString();
            StructString S2 = new StructString();
            S1.txt = textBox1.Text;
            S2.txt = textBox2.Text;

            Console.WriteLine(S1.txt);
            Console.WriteLine(S2.txt);
            Console.WriteLine(String.Concat(S1.txt, S2.txt));

            textBox3.Text = String.Concat(S1.txt, S2.txt);

        }
    }
}

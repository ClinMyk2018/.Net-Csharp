﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W4.T2Class.ClinardBrandi
{
    class ClassEx
    {
        public String text;

        public ClassEx()
        {
        }

        public ClassEx(string text)
        {
            this.text = text;
        }

        public void SetClassTxt(string newText)
        {
            text = newText;
        }


    }
}

﻿namespace W2.T4.ClinardMykal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.but7 = new System.Windows.Forms.Button();
            this.but8 = new System.Windows.Forms.Button();
            this.but9 = new System.Windows.Forms.Button();
            this.butC = new System.Windows.Forms.Button();
            this.but4 = new System.Windows.Forms.Button();
            this.but5 = new System.Windows.Forms.Button();
            this.but6 = new System.Windows.Forms.Button();
            this.butPlus = new System.Windows.Forms.Button();
            this.but1 = new System.Windows.Forms.Button();
            this.but2 = new System.Windows.Forms.Button();
            this.but3 = new System.Windows.Forms.Button();
            this.butMinus = new System.Windows.Forms.Button();
            this.buttonNone1 = new System.Windows.Forms.Button();
            this.butDivide = new System.Windows.Forms.Button();
            this.butDecimal = new System.Windows.Forms.Button();
            this.butEnter = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.butMultiply = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(52, 21);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(193, 31);
            this.textBox1.TabIndex = 0;
            // 
            // but7
            // 
            this.but7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but7.Location = new System.Drawing.Point(52, 60);
            this.but7.Name = "but7";
            this.but7.Size = new System.Drawing.Size(36, 23);
            this.but7.TabIndex = 1;
            this.but7.Text = "7";
            this.but7.UseVisualStyleBackColor = true;
            this.but7.Click += new System.EventHandler(this.but7_Click);
            // 
            // but8
            // 
            this.but8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but8.Location = new System.Drawing.Point(103, 60);
            this.but8.Name = "but8";
            this.but8.Size = new System.Drawing.Size(36, 23);
            this.but8.TabIndex = 2;
            this.but8.Text = "8";
            this.but8.UseVisualStyleBackColor = true;
            this.but8.Click += new System.EventHandler(this.but8_Click);
            // 
            // but9
            // 
            this.but9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but9.Location = new System.Drawing.Point(156, 61);
            this.but9.Name = "but9";
            this.but9.Size = new System.Drawing.Size(36, 23);
            this.but9.TabIndex = 3;
            this.but9.Text = "9";
            this.but9.UseVisualStyleBackColor = true;
            this.but9.Click += new System.EventHandler(this.but9_Click);
            // 
            // butC
            // 
            this.butC.BackColor = System.Drawing.Color.Maroon;
            this.butC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butC.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.butC.Location = new System.Drawing.Point(209, 60);
            this.butC.Name = "butC";
            this.butC.Size = new System.Drawing.Size(36, 23);
            this.butC.TabIndex = 4;
            this.butC.Text = "C";
            this.butC.UseVisualStyleBackColor = false;
            this.butC.Click += new System.EventHandler(this.butC_Click);
            // 
            // but4
            // 
            this.but4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but4.Location = new System.Drawing.Point(52, 97);
            this.but4.Name = "but4";
            this.but4.Size = new System.Drawing.Size(36, 23);
            this.but4.TabIndex = 6;
            this.but4.Text = "4";
            this.but4.UseVisualStyleBackColor = true;
            this.but4.Click += new System.EventHandler(this.but4_Click);
            // 
            // but5
            // 
            this.but5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but5.Location = new System.Drawing.Point(103, 97);
            this.but5.Name = "but5";
            this.but5.Size = new System.Drawing.Size(36, 23);
            this.but5.TabIndex = 7;
            this.but5.Text = "5";
            this.but5.UseVisualStyleBackColor = true;
            this.but5.Click += new System.EventHandler(this.but5_Click);
            // 
            // but6
            // 
            this.but6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but6.Location = new System.Drawing.Point(156, 97);
            this.but6.Name = "but6";
            this.but6.Size = new System.Drawing.Size(36, 23);
            this.but6.TabIndex = 8;
            this.but6.Text = "6";
            this.but6.UseVisualStyleBackColor = true;
            this.but6.Click += new System.EventHandler(this.but6_Click);
            // 
            // butPlus
            // 
            this.butPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butPlus.Location = new System.Drawing.Point(209, 97);
            this.butPlus.Name = "butPlus";
            this.butPlus.Size = new System.Drawing.Size(36, 23);
            this.butPlus.TabIndex = 9;
            this.butPlus.Text = "+";
            this.butPlus.UseVisualStyleBackColor = true;
            this.butPlus.Click += new System.EventHandler(this.butPlus_Click);
            // 
            // but1
            // 
            this.but1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but1.Location = new System.Drawing.Point(52, 135);
            this.but1.Name = "but1";
            this.but1.Size = new System.Drawing.Size(36, 23);
            this.but1.TabIndex = 11;
            this.but1.Text = "1";
            this.but1.UseVisualStyleBackColor = true;
            this.but1.Click += new System.EventHandler(this.but1_Click);
            // 
            // but2
            // 
            this.but2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but2.Location = new System.Drawing.Point(103, 135);
            this.but2.Name = "but2";
            this.but2.Size = new System.Drawing.Size(36, 23);
            this.but2.TabIndex = 12;
            this.but2.Text = "2";
            this.but2.UseVisualStyleBackColor = true;
            this.but2.Click += new System.EventHandler(this.but2_Click);
            // 
            // but3
            // 
            this.but3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but3.Location = new System.Drawing.Point(156, 135);
            this.but3.Name = "but3";
            this.but3.Size = new System.Drawing.Size(36, 23);
            this.but3.TabIndex = 13;
            this.but3.Text = "3";
            this.but3.UseVisualStyleBackColor = true;
            this.but3.Click += new System.EventHandler(this.but3_Click);
            // 
            // butMinus
            // 
            this.butMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butMinus.Location = new System.Drawing.Point(209, 135);
            this.butMinus.Name = "butMinus";
            this.butMinus.Size = new System.Drawing.Size(36, 23);
            this.butMinus.TabIndex = 14;
            this.butMinus.Text = "-";
            this.butMinus.UseVisualStyleBackColor = true;
            this.butMinus.Click += new System.EventHandler(this.butMinus_Click);
            // 
            // buttonNone1
            // 
            this.buttonNone1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNone1.Location = new System.Drawing.Point(52, 175);
            this.buttonNone1.Name = "buttonNone1";
            this.buttonNone1.Size = new System.Drawing.Size(36, 23);
            this.buttonNone1.TabIndex = 16;
            this.buttonNone1.UseVisualStyleBackColor = true;
            // 
            // butDivide
            // 
            this.butDivide.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butDivide.Location = new System.Drawing.Point(209, 217);
            this.butDivide.Name = "butDivide";
            this.butDivide.Size = new System.Drawing.Size(36, 23);
            this.butDivide.TabIndex = 17;
            this.butDivide.Text = "/";
            this.butDivide.UseVisualStyleBackColor = true;
            this.butDivide.Click += new System.EventHandler(this.butDivide_Click);
            // 
            // butDecimal
            // 
            this.butDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butDecimal.Location = new System.Drawing.Point(156, 175);
            this.butDecimal.Name = "butDecimal";
            this.butDecimal.Size = new System.Drawing.Size(36, 23);
            this.butDecimal.TabIndex = 18;
            this.butDecimal.Text = ".";
            this.butDecimal.UseVisualStyleBackColor = true;
            this.butDecimal.Click += new System.EventHandler(this.butDecimal_Click);
            // 
            // butEnter
            // 
            this.butEnter.BackColor = System.Drawing.Color.Green;
            this.butEnter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butEnter.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.butEnter.Location = new System.Drawing.Point(52, 217);
            this.butEnter.Name = "butEnter";
            this.butEnter.Size = new System.Drawing.Size(140, 23);
            this.butEnter.TabIndex = 19;
            this.butEnter.Text = "Enter";
            this.butEnter.UseVisualStyleBackColor = false;
            this.butEnter.Click += new System.EventHandler(this.butEnter_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(103, 175);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(36, 23);
            this.button1.TabIndex = 20;
            this.button1.Text = "0";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // butMultiply
            // 
            this.butMultiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butMultiply.Location = new System.Drawing.Point(209, 175);
            this.butMultiply.Name = "butMultiply";
            this.butMultiply.Size = new System.Drawing.Size(36, 23);
            this.butMultiply.TabIndex = 21;
            this.butMultiply.Text = "*";
            this.butMultiply.UseVisualStyleBackColor = true;
            this.butMultiply.Click += new System.EventHandler(this.butMultiply_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 260);
            this.Controls.Add(this.butMultiply);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.butEnter);
            this.Controls.Add(this.butDecimal);
            this.Controls.Add(this.butDivide);
            this.Controls.Add(this.buttonNone1);
            this.Controls.Add(this.butMinus);
            this.Controls.Add(this.but3);
            this.Controls.Add(this.but2);
            this.Controls.Add(this.but1);
            this.Controls.Add(this.butPlus);
            this.Controls.Add(this.but6);
            this.Controls.Add(this.but5);
            this.Controls.Add(this.but4);
            this.Controls.Add(this.butC);
            this.Controls.Add(this.but9);
            this.Controls.Add(this.but8);
            this.Controls.Add(this.but7);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button but7;
        private System.Windows.Forms.Button but8;
        private System.Windows.Forms.Button but9;
        private System.Windows.Forms.Button butC;
        private System.Windows.Forms.Button but4;
        private System.Windows.Forms.Button but5;
        private System.Windows.Forms.Button but6;
        private System.Windows.Forms.Button butPlus;
        private System.Windows.Forms.Button but1;
        private System.Windows.Forms.Button but2;
        private System.Windows.Forms.Button but3;
        private System.Windows.Forms.Button butMinus;
        private System.Windows.Forms.Button buttonNone1;
        private System.Windows.Forms.Button butDivide;
        private System.Windows.Forms.Button butDecimal;
        private System.Windows.Forms.Button butEnter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button butMultiply;
    }
}

